using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;

public static class KoscheiBuild
{
    private const string ScenePath = "Assets/Scenes/Main.unity";
    private const string BuildDirectory = "Build/android";
    private const string ApkPath = BuildDirectory + "/koschei-runner-template.apk";
    private const string AabPath = BuildDirectory + "/koschei-runner-template.aab";
    private const string IconAssetPath = "Assets/Resources/koschei-icon.png";
    private const string BuildConfigPath = "Assets/Koschei/Generated/koschei-build-config.json";

    public static void BuildAndroidApk()
    {
        PrepareProjectForBuild();
        BuildAndroid(ApkPath, BuildOptions.None);
    }

    public static void BuildAndroidAab()
    {
        PrepareProjectForBuild();
        var previousBuildAppBundle = EditorUserBuildSettings.buildAppBundle;

        try
        {
            EditorUserBuildSettings.buildAppBundle = true;
            BuildAndroid(AabPath, BuildOptions.None);
        }
        finally
        {
            EditorUserBuildSettings.buildAppBundle = previousBuildAppBundle;
        }
    }

    private static void PrepareProjectForBuild()
    {
        PlayerSettings.companyName = "Koschei Game Factory";
        if (!File.Exists(BuildConfigPath))
        {
            PlayerSettings.productName = "Koschei Runner";
            PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, "com.koschei.generated.runner");
        }

        AssignKoscheiIcon();

        Directory.CreateDirectory(BuildDirectory);
        AssetDatabase.SaveAssets();
    }

    private static void AssignKoscheiIcon()
    {
        if (!File.Exists(IconAssetPath))
        {
            var iconTexture = GenerateKoscheiIconTexture();
            File.WriteAllBytes(IconAssetPath, iconTexture.EncodeToPNG());
            AssetDatabase.Refresh();
        }

        var icon = AssetDatabase.LoadAssetAtPath<Texture2D>(IconAssetPath);
        if (icon == null)
        {
            Debug.LogWarning("[KoscheiBuild] Failed to load icon texture.");
            return;
        }

        PlayerSettings.SetIconsForTargetGroup(BuildTargetGroup.Android, new[] { icon });
    }

    private static Texture2D GenerateKoscheiIconTexture()
    {
        const int size = 512;
        var texture = new Texture2D(size, size, TextureFormat.RGBA32, false);
        var background = new Color(0.13f, 0.17f, 0.46f);
        var accent = new Color(0.95f, 0.84f, 0.2f);

        for (var y = 0; y < size; y++)
        {
            for (var x = 0; x < size; x++)
            {
                texture.SetPixel(x, y, background);
            }
        }

        for (var y = 96; y < 416; y++)
        {
            for (var x = 110; x < 175; x++)
            {
                texture.SetPixel(x, y, accent);
            }

            for (var x = 175; x < 405; x++)
            {
                var waveY = Mathf.Sin((y - 96) * 0.03f) * 9f;
                if (Mathf.Abs((y - 256) - waveY) < 33)
                {
                    texture.SetPixel(x, y, accent);
                }
            }
        }

        texture.Apply();
        return texture;
    }

    private static string[] EnsureBuildScenes()
    {
        var enabledScenes = EditorBuildSettings.scenes
            .Where(scene => scene.enabled && !string.IsNullOrEmpty(scene.path))
            .Select(scene => scene.path)
            .ToArray();

        if (enabledScenes.Length > 0)
        {
            return enabledScenes;
        }

        Directory.CreateDirectory(Path.GetDirectoryName(ScenePath)!);

        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        var cameraObject = new GameObject("Main Camera");
        var camera = cameraObject.AddComponent<Camera>();
        cameraObject.tag = "MainCamera";
        camera.orthographic = true;
        camera.orthographicSize = 5.5f;
        camera.transform.position = new Vector3(0f, 1f, -10f);

        var lightObject = new GameObject("Directional Light");
        var light = lightObject.AddComponent<Light>();
        light.type = LightType.Directional;

        new GameObject("KoscheiGameRoot");

        EditorSceneManager.SaveScene(scene, ScenePath);
        AssetDatabase.Refresh();

        EditorBuildSettings.scenes = new[]
        {
            new EditorBuildSettingsScene(ScenePath, true)
        };

        return new[] { ScenePath };
    }

    private static void BuildAndroid(string outputPath, BuildOptions options)
    {
        if (!EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android))
        {
            throw new System.Exception("Failed to switch active build target to Android.");
        }

        var buildScenes = EnsureBuildScenes();
        var report = BuildPipeline.BuildPlayer(new BuildPlayerOptions
        {
            scenes = buildScenes,
            locationPathName = outputPath,
            target = BuildTarget.Android,
            options = options
        });

        if (report.summary.result != BuildResult.Succeeded)
        {
            throw new System.Exception($"Android build failed: {report.summary.result}");
        }

        Debug.Log($"[KoscheiBuild] Build completed: {outputPath}");
    }
}
