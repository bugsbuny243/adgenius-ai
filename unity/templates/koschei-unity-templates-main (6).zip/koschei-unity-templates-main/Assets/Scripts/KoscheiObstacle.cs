using UnityEngine;

public class KoscheiObstacle : MonoBehaviour
{
    [SerializeField] private float moveSpeed = 5.8f;
    [SerializeField] private float destroyX = -9f;

    public void Configure(float speed, float despawnX)
    {
        moveSpeed = speed;
        destroyX = despawnX;
    }

    private void Update()
    {
        transform.position += Vector3.left * (moveSpeed * Time.deltaTime);
        if (transform.position.x <= destroyX)
        {
            Destroy(gameObject);
        }
    }
}
