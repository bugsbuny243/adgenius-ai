using UnityEngine;

public static class KoscheiRuntimeBootstrap
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void EnsureKoscheiRunnerIsLoaded()
    {
        if (Object.FindFirstObjectByType<KoscheiRunnerGame>() != null)
        {
            return;
        }

        var root = new GameObject("KoscheiRunnerRuntime");
        root.AddComponent<KoscheiRunnerGame>();
    }
}
