using System;

[Serializable]
public class KoscheiBuildConfig
{
    public string project_id;
    public string build_job_id;
    public string app_name;
    public string package_name;
    public string version_name;
    public int version_code;
    public string game_type;
    public string short_description;
    public string visual_style;
    public string controls;
    public string[] features;
    public string target_platform;
}
