using System;
using UnityEngine;

namespace Koschei.Generated
{
    [Serializable]
    public class KoscheiGeneratedGameConfig
    {
        public string gameTitle = "Gece Koşucusu";
        public string packageName = "com.koschei.generated.gecekosucusu";
        public string gameType = "runner_2d";
        public string promptSummary = "Unity dosyaları üretime hazırlandı (3 dosya).";
        public string playerColor = "#EA42F0";
        public string groundColor = "#725A31";
        public string obstacleColor = "#29E060";
        public float speedMultiplier = 1.18f;
        public float jumpForce = 9f;
        public string scoreLabel = "Skor";
        public string releaseVersion = "1.0+1";

        public static KoscheiGeneratedGameConfig LoadFromTextAsset(TextAsset jsonAsset)
        {
            if (jsonAsset == null || string.IsNullOrWhiteSpace(jsonAsset.text))
            {
                return new KoscheiGeneratedGameConfig();
            }

            return JsonUtility.FromJson<KoscheiGeneratedGameConfig>(jsonAsset.text) ?? new KoscheiGeneratedGameConfig();
        }
    }
}
